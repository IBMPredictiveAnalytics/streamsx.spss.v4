#!/usr/bin/perl -w
# begin_generated_IBM_copyright_prolog                             
#                                                                  
# This is an automatically generated copyright prolog.             
# After initializing,  DO NOT MODIFY OR MOVE                       
# **************************************************************** 
#Licensed Materials - Property of IBM
#IBM SPSS Products: Analytics Toolkit
#(C) Copyright IBM Corp. 2014 All Rights Reserved. 
#US Government Users Restricted Rights - Use, duplication or      
#disclosure restricted by GSA ADP Schedule Contract with          
#IBM Corp.                                

use strict;
use Cwd 'realpath';
use File::Basename;

if ($ARGV[0] eq '-h')
{
	print "Usage: SpssLibInfo.pl [-h] [libPath]\n";
	exit;
}
my $CLEMRUNTIME = $ENV{'CLEMRUNTIME'};

my @PSAPILIB = ("$CLEMRUNTIME/lib");

my @JARFILES = <@PSAPILIB/*.jar>;

if ($ARGV[0] eq 'libPath'){
	foreach my $JARFILE (@JARFILES) {
    	print "$JARFILE\n";
	}
}

exit 0;


